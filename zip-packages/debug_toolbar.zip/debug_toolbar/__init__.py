VERSION = (0, 8, 4)
__version__ = '.'.join(map(str, VERSION))
